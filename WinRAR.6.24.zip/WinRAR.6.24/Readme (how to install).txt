1. Install WinRAR
2. Copy file rarreg.key
3. Paste in C:\Program Files\WinRAR